using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Exitdoor : CircuitComponent
{
    public Sprite openSprite;
    private void Update()
    {
        if (EnergyInput == 45)
            gameObject.GetComponent<Image>().sprite = openSprite;
        else
            gameObject.GetComponent<Image>().sprite = initialSprite;
    }
}
