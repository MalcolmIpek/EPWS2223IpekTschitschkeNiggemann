using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class DragAndDrop : MonoBehaviour, IPointerDownHandler, IBeginDragHandler, IEndDragHandler, IDragHandler, IDropHandler
{
    [SerializeField] private Canvas canvas;

    private RectTransform rectTransform;
    private CanvasGroup canvasGroup;

    public Vector2 initialPosition;

    private void Awake()
    {
        canvas = FindObjectOfType<Canvas>();
        rectTransform= GetComponent<RectTransform>();
        canvasGroup = GetComponent<CanvasGroup>();
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        Debug.Log("Begin drag!");
        initialPosition= gameObject.transform.position;
        gameObject.transform.parent = GameObject.Find("Canvas").transform;
        canvasGroup.alpha= .6f;
        canvasGroup.blocksRaycasts= false;

        if (eventData.pointerDrag.GetComponent<CircuitComponent>().socket != null)
        {
            eventData.pointerDrag.GetComponent<CircuitComponent>().socket.holdsCircuitComponent = false;
            eventData.pointerDrag.GetComponent<CircuitComponent>().socket.component = null;
            eventData.pointerDrag.GetComponent<CircuitComponent>().socket = null;
        }
    }

    public void OnDrag(PointerEventData eventData)
    {
        rectTransform.anchoredPosition += eventData.delta / canvas.scaleFactor;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        InventoryManager.Instance.Remove(gameObject.GetComponent<CircuitComponent>().item);

        Debug.Log("End drag!");
        if (eventData.pointerCurrentRaycast.gameObject == null || eventData.pointerCurrentRaycast.gameObject.CompareTag("Untagged") && GameObject.Find("Inventory"))
        {
            InventoryManager.Instance.Add(gameObject.GetComponent<CircuitComponent>().item);

            gameObject.transform.parent = GameObject.Find("Content").transform;
        }
        else if (eventData.pointerCurrentRaycast.gameObject == null || eventData.pointerCurrentRaycast.gameObject.CompareTag("Untagged") && (!GameObject.Find("Incentory")) && GameObject.Find("Fusebox UI Element"))
        {
            gameObject.transform.parent = GameObject.Find("Fusebox UI Element").transform;
            gameObject.transform.position = initialPosition;
        }
        else if (eventData.pointerCurrentRaycast.gameObject == GameObject.Find("Fusebox UI Element"))
        {
            gameObject.transform.parent = eventData.pointerCurrentRaycast.gameObject.transform;
        }
        else if (eventData.pointerCurrentRaycast.gameObject == GameObject.Find("Inventory"))
        {
            InventoryManager.Instance.Add(gameObject.GetComponent<CircuitComponent>().item);

            gameObject.transform.parent = GameObject.Find("Content").transform;
        }
        //else gameObject.transform.position = initialPosition;
        canvasGroup.alpha = 1f;
        canvasGroup.blocksRaycasts= true;
        
        if(eventData.pointerPressRaycast.gameObject != null) initialPosition = gameObject.transform.position;
    }
   
    public void OnPointerDown(PointerEventData eventData)
    {
        Debug.Log("Drag!");
    }

    public void OnDrop(PointerEventData eventData)
    {
        Debug.Log("Dropping item");
    }
}
